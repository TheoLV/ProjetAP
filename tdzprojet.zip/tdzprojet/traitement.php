<?php
    $serveur = "localhost";
    $dbname = "GSBV2";
    $user = "root";
    $pass = "password";
    
    try{
        //On se connecte à la BDD
        $dbco = new PDO("mysql:host=$serveur;dbname=$dbname",$user,$pass);
        $dbco->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
        //On crée une table form
        $form = "CREATE TABLE form(
            nom TEXT,
            prenom TEXT,
            Service TEXT,
            date DATE,
            Description TEXT,
            hebergement TEXT,
            deplacement TEXT,
            
            
            )";
        $dbco->exec($form);
    }
    catch(PDOException $e){
        echo 'Erreur : '.$e->getMessage();
    }
?>