<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="styleconsultfich.css" />
        <title>Consulter sa fiche</title>
    </head>    
    <body>
        <h1>Consulter ses fiches</h1>
        <div id="conteneur">
            <div class="traj">Trajet</div>
            <div class="infotraj">Informations sur le trajet, date, heure, frais totaux...</div>
        </div>

        <div id="conteneur2">
            <div class="hotel">Hôtel</div>
            <div class="infohotel">Informations sur l'hôtel, date, lieu, frais totaux...</div>
        </div>
        
    </body>
</html>        