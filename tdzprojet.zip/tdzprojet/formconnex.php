<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="styleform.css" />
        <title>Formulaire de connexion</title>
    </head>

    <body>
        <div class="fond">
        <h1>Se connecter</h1> <br />
        <form method="POST" action="traitement.php">
            <p>
                <label for="name">Identifiant : </label></label><input type="text" name="name" size="30px" /> <br />
                <label for="password">Mot de passe : </label></label><input type="password" name="password" size="30px" /> <br />
            </p>
            </form>
        
        <div id="conteneur">
            <div class="fichfrais"><a href="fichefrais.php"><button type="submit">Renseigner sa fiche frais</button></a></div>
            <div class="consultfich"><a href="consultfich.php"><button type="submit">Consulter ses fiches</button></a></div>
        </div>
        </div>

    </body>
</html>