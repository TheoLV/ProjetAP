<!DOCTYPE html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="styleaccueil.css" />
        <title>Accueil</title>
    </head>
    <body>
            <h1 class="TitreNDF">Note de frais</h1>
            <a href="formconnex.php"><p class="bouton"><button type="submit">Se connecter</button></p></a>
        <h2><u>Présentation brève de l'entreprise</u></h2>
            <p>Le laboratoire Galaxy Swiss Bourdin (GSB) est issu de la fusion entre le géant américain Galaxy 
                (spécialisé dans le secteur des maladies virales dont le SIDA et les hépatites) et le conglomérat européen Swiss Bourdin
                (travaillant sur des médicaments plus conventionnels), lui-même déjà union de trois petits laboratoires.
                En 2009, les deux géants pharmaceutiques ont uni leurs forces pour créer un leader de ce secteur industriel,
                fort de 4 500 salariés à travers le monde. Le siège social de la multinationale est situé à Philadelphie, Pennsylvanie, aux Etats-Unis. 
                Une conséquence de cette fusion a été la recherche d'une optimisation de l’activité du groupe 
                ainsi constitué en réalisant des économies d’échelle dans l’organisation administrative,
                la recherche-développement, la production et la distribution de médicaments.
                Il s’est agi de réorganiser la nouvelle entité en réduisant drastiquement
                les coûts et en conservant uniquement le meilleur des deux laboratoires pour se doter d’avantages
                et ainsi faire face aux entreprises concurrentes.</p>

                <footer>
                    <p class="butoncgu"><a href="rgpd.php"><button type="submit">CGU</button></a></p>
                    <p>
                        Nous sommes le <?php echo date ('d/m/Y h:i:s'); ?>
                    </p>
                </footer>
    </body>