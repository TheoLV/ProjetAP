<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="stylefichefrais.css" />
        <title>Renseigner sa fiche</title>
    </head>    
    <body>
        <h1>Renseigner sa fiche de frais</h1>
        <form action="consultfich.php" method="POST">
            <div class="formulaires">
            <p>
                <label for="name">Nom : </label></label><input type="text" name="name" placeholder="Ex : Dupont" size="30px" /> <br />
                <label for="firstname">Prénom : </label></label><input type="text" name="firsname" placeholder="Ex : Pierre" size="30px" /> <br />
                <label for="service">Service : </label></label><input type="text" name="service" size="30px" /> <br />
                <label for="date">Date : </label></label><input type="date" name="date" size="30px" /> <br />
                <label for="description">Description : </label><textarea name="description" id="description"></textarea> <br />
                <label for="hosting">Coût hébergement : </label></label><input type="text" name="hosting" placeholder="Ex : 75€" size="30px" /> <br />
                <label for="travel">Coût déplacement : </label></label><input type="text" name="travel" placeholder="Ex : 100€" size="30px" /> <br />
                <label for="meal">Coût repas : </label></label><input type="text" name="meal" placeholder="Ex : 25€" size="30px" /> <br />
                <label for="other">Autre(s) : </label></label><input type="text" name="other" size="30px" /> <br />
                <label for="total">Coût total : </label></label><input type="text" name="total" placeholder="Ex : 135€" size="30px" /> <br />
            </p>
            </div>
            <a href="consultfich.php"><p class="confirmer"><button type="submit">Confirmer</button></a></p>

        </form>

    </body>
</html>    
